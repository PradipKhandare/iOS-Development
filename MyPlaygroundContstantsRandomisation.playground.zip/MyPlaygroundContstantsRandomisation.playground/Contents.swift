//let a = 9
//
////a = 6
//
//print(a)
//var randomNumber = Int.random(in: 1...10)
//print(randomNumber)

//PASSWORD GENERATOR

func()
{
    
    let alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m"
                        ,"n", "o", "p","q", "r", "s", "t", "u", "v", "w", "x"
                        ,"y", "z"]
    
    
}
