import UIKit

//var carDictionary: [String: String] = ["Audi":"R8", "Nissan":"Rogue", "BMW":"X3"]
//print(carDictionary["Audi"]!)
//carDictionary["Audi"] = "R7"
//print(carDictionary["Audi"]!)


var nameAndSurname: [String: String] = ["Pradip": "Khandare", "Avinash": "Kamble"]
print(nameAndSurname)

var x: [String: Any] = ["Pradip":7, "Kalki":"Disha"]
print(x)
