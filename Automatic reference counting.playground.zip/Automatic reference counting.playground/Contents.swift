import UIKit

class Person
{
    var name: String
   weak var job: Job?
    init(name: String) {
        debugPrint("init method of Person called")
        self.name = name
    }
    
    func printName() {
        debugPrint("name is \(name)")
    }
    
    deinit {
        debugPrint("deinit called for person class")
    }
    
}

//var objPerson1: Person?
//var objPerson2: Person?
//
//if(1 == 1)
//{
//    let objPerson = Person(name: "Pradip")
//    objPerson1 = objPerson
//    objPerson2 = objPerson
//    objPerson.printName()
//}


class Job
{
    var jobSescriotion: String
   weak var person: Person?
    
    init(jobSescriotion: String) {
        debugPrint("init method of Job called")
        self.jobSescriotion = jobSescriotion
    }
    
    func printName() {
        debugPrint("name is \(jobSescriotion)")
    }
    
    deinit {
        debugPrint("deinit called for job class")
    }
    
}

if(1 == 1)
{
    let objPerson = Person(name: "Pradip")
    let objJob = Job(jobSescriotion: "Coder")
    objPerson.job = objJob
    objJob.person = objPerson
}
