func greeting() {
    print("Helloo")
    
    var name = "Pradip"
    print(name)
}

greeting()

func fourtimesHello() {
    for i in 1...4 {
        print("Hello \(i)")
    }
}
fourtimesHello()
