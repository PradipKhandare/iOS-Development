var player :  String? = nil

player = "Pradip"
//print(player!)

player = nil
if player != nil {
    print(player!)
}



var names : [String : String] = [
    "FirstName"  : "Pradip",
    "LastName" : "Khandare"
    ]
let n = names["FirstName"]

switch n {
case "Pradip" :
    print("It is first name")
case "Khandare" :
    print("It is last name")
default :
    print("Error")
}

