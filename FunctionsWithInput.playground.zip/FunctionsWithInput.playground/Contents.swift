//func greet(whoAreYou : String) {
//    print("Hello \(whoAreYou)")
//}
//greet(whoAreYou : "Pradip")

func add(n1 : Int, n2 : Int) {
    print("Summation in \(n1 + n2)")
}
func subtract(n1 : Int, n2 : Int) {
    print("subtraction is \(n1 - n2)")
}
func mult(n1 : Int, n2 : Int) {
    print("multiplication is \(n1 * n2)")
}
func divide(n1 : Int, n2 : Int) {
    print("division is \(n1/n2)")
}

add(n1: 10, n2: 15)
subtract(n1: 15, n2: 10)
mult(n1: 10, n2: 10)
divide(n1: 50, n2: 10)
