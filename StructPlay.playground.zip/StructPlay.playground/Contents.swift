struct Town {
    let name = "Lonar"
    var citizens = ["Pradip", "Vijay"]
    var resourcse = ["farm" : 100, "Job": 300, "worker" : 600]
    
    func fortify(){
        print("Defences increased")
    }
}

var myTown = Town()

print(myTown.citizens)
print(myTown.name)
print(myTown.resourcse["farm"]!)

myTown.citizens.append("tukya")
print(myTown.citizens)

myTown.fortify()



struct City {
    
    let name : String
    var people : [String]
    var resources : [String : Int]
    
    init(n : String, p : [String], r : [String : Int]){
        name = n
        people = p
        resources = r
    }
}
var obj = City(n: "Pradip", p: ["Vijay", "Avi"], r: ["Farming" : 1, "Food" : 2])
print(obj)
obj.people.append("Raj")
print(obj.people)
