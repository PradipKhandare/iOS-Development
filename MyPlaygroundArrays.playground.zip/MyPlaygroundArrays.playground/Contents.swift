var names : [String] = ["Pradip", "Shubham", "Vijay"]
print(names)

var numbers : [Int] = [2, 3, 4, 5]

var result : [Int] = []

for n in 0..<numbers.count - 1 {
    let ans = numbers[n] * numbers[n+1]
    result.append(ans)
}
print("Original array is \(numbers)")
print("computed array is \(result)")

