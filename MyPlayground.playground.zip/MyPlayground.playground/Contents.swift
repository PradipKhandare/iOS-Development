print("Hello world")
print("hello \(2+3) world")
print("The result of 5 + 3 = \(5+3)")

