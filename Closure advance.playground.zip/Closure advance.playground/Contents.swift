import UIKit

func printGoodMorning(isMorning: Bool, name: () -> String)
{
    if(isMorning)
    {
        debugPrint("Good Morning \(name())")
    }
}


func assignName(name: String) -> String
{
    debugPrint("assign name is called")
    return name
}
//printGoodMorning(isMorning: true, name: assignName(name: "Pradip"))
//printGoodMorning(isMorning: true, name: assignName(name: "Ratalya"))

printGoodMorning(isMorning: true) { () -> String in
    assignName(name: "Pradu")
}



//typealias AdditionOfTwoNumberClosure = (_ number1: Int, _ number2: Int) -> Int
//let additionClosure : AdditionOfTwoNumberClosure =
//{
//    (_ number1: Int, _ number2: Int) -> Int in
//    return number1 + number2
//}
//debugPrint("Result is = \(additionClosure(1,1))")
//
//let substraction : (_ num1: Int, _ num2: Int) -> Int =
//{
//    (_ num1: Int, _ num2: Int) -> Int in
//    return num1 - num2
//}
//debugPrint("answer is \(substraction(10,1))")

