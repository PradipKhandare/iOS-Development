import UIKit

////https://jsonplaceholder.typicode.com/posts

//{
//"userId": 1,
//"id": 1,
//"title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
//"body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
//},

//---------------------------------------------------------------------------------------------------------------------------------------------------------------

struct EmployeeResponse: Decodable
{
    let userId, id : Int
    let title, body : String
    
}

struct ProductsList: Decodable {
    let userID, id: Int
    let title, body: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}


struct HttpUtility
{
    func getApiData<T:Decodable>(requestUrl: URL, resultType: T.Type, completionHandler:@escaping(_ result: T) -> Void)
    {
        URLSession.shared.dataTask(with: requestUrl) { (responseData, httpUrlResponse, error) in
            
            if(error == nil && responseData != nil && responseData?.count != 0)
            {
                let decoder = JSONDecoder()
                do{
                    let result = try decoder.decode(T.self, from: responseData!)
                    _=completionHandler(result)
                }catch let error {
                    
                    debugPrint("error occured while decoding = \(error.localizedDescription)")
                }
                
            }
        }.resume()
    }
}

struct Employee 
{
    
    private let httpUtility: HttpUtility
    
    init(_httpUtility: HttpUtility) {
        httpUtility = _httpUtility
        
    }
    
    func getEmployeeData()
    {
        let employeeApiUrl = "https://jsonplaceholder.typicode.com/posts/1"
    
        httpUtility.getApiData(requestUrl: URL(string: employeeApiUrl)!, resultType: EmployeeResponse.self) { result in
           
                debugPrint(result)
            
        }
    }
        
//        URLSession.shared.dataTask(with: URL(string: employeeApiUrl)!) { (responseData, httpUrlResponse, error) in
//            
//            if(error == nil && responseData != nil && responseData?.count != 0)
//            {
//                let decoder = JSONDecoder()
//                do{
//                    let result = try decoder.decode(EmployeeResponse.self, from: responseData!)
//                    debugPrint(result.title)
//                }catch let error {
//                    
//                    debugPrint("error occured while decoding = \(error.localizedDescription)")
//                }
//                
//            }
//        }
      
    func getReportsData()
    {
        let reportsApi = "https://jsonplaceholder.typicode.com/posts"
        httpUtility.getApiData(requestUrl: URL(string: reportsApi)!, resultType: [ProductsList].self) { result in
            if(result.count != 0)
            {
                for emp in result
                {
                    debugPrint(emp.id)
                }
        }
    }
//        URLSession.shared.dataTask(with: URL(string: reportsApi)!) { responseData, httpUrlResponse, error in
//            if(error == nil && responseData != nil && responseData?.count != 0)
//            {
//                let decoder = JSONDecoder()
//                do
//                {
//                    let ReportsResult = try decoder.decode([ProductsList].self, from: responseData!)
//                    for report in ReportsResult
//                    {
//                        debugPrint(report.userID)
//                    }
//                } catch let error {
//                    debugPrint("eror occured while decoding = \(error.localizedDescription)")
//                }
//            }
//        }.resume()
    }
}

let objEmp = Employee(_httpUtility: HttpUtility())
objEmp.getEmployeeData()
objEmp.getReportsData()

//-------------------------------------------------------------------------------------------------------------------------------------------------------------gg

//struct iphoneResponse: Decodable
//{
//    let count, age: Int
//    let name: String
//}
//
//
//struct Iphone
//{
//    func getIphoneDetails()
//    {
//        let apiUrl = "https://api.agify.io/?name=meelad"
//        
//        URLSession.shared.dataTask(with: URL(string: apiUrl)!) { responseData, httpUrlResponse, error in
//            
//            if(error == nil && responseData != nil && responseData?.count != 0)
//            {
//                let decoder = JSONDecoder()
//                do{
//                    let result = try decoder.decode(iphoneResponse.self, from: responseData!)
//                    debugPrint(result.name)
//                }catch let error {
//                    debugPrint("error occure while decoding = \(error.localizedDescription)")
//                }
//               
//            }
//        }
//        .resume()
//    }
//}
//let objIphone = Iphone()
//objIphone.getIphoneDetails()

//----------------------------------------------------------------------------------------------------------------------------------------------------------------

// MARK: - Welcome
//struct Welcome: Codable {
//    let products: [Product]
//    let total, skip, limit: Int
//}
//
//// MARK: - Product
//struct Product: Codable {
//    let id: Int
//    let title, description: String
//    let price: Int
//    let discountPercentage, rating: Double
//    let stock: Int
//    let brand, category: String
//    let thumbnail: String
//    let images: [String]
//}
//
//
//
//struct Users
//{
//    func getUsers()
//    {
//        let url = "https://dummyjson.com/products"
//        URLSession.shared.dataTask(with: URL(string: url)!) { responseData, httpResopnse, error in
//            
//            if(responseData != nil && responseData?.count != 0 && error == nil)
//            {
//                let decoder = JSONDecoder()
//                do
//                {
//                    let result = try decoder.decode([Product].self, from: responseData!)
//                }catch let error
//                {
//                    debugPrint("error occure during decoding = \(error.localizedDescription)")
//                }
//            }
//        }.resume()
//    }
//}
//
//let objUsers = Users()
//objUsers.getUsers()

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------

//https://jsonplaceholder.typicode.com/posts

struct DataDummyResponse: Decodable
{
        let userID, id: Int
        let title, body: String

        enum CodingKeys: String, CodingKey {
            case userID = "userId"
            case id, title, body
        }

}

struct HttpUtilitySecond
{
    func getApiDataFromDummy<T:Decodable>(requestUrl: URL, resultType: T.Type, completionHandler:@escaping(_ result: T) -> Void)
    {
        URLSession.shared.dataTask(with: requestUrl) { (responseData, httpUrlResponse, error) in
            if(responseData != nil && responseData?.count != 0 && error == nil)
            {
             let decoder = JSONDecoder()
                do
                {
                    let result = try decoder.decode(T.self, from: responseData!)
                    _=completionHandler(result)
                }catch let error {
                    debugPrint("the error occured is = \(error.localizedDescription)")
                }
            }
        }.resume()
    }
}

struct DummyData
{
    private var httpUtility: HttpUtility
    
    init(_httpUtility: HttpUtility) {
        httpUtility = _httpUtility
    }
    let dummyUrl = "https://jsonplaceholder.typicode.com/posts"
    
    func getDummydata()
    {
    
        httpUtility.getApiData(requestUrl: URL(string: dummyUrl)!, resultType: [DataDummyResponse].self) { result in
            if(result.count != 0)
            {
                for dummyData in result
                {
                    debugPrint(dummyData.title)
                    debugPrint(dummyData.id)
                    debugPrint(dummyData.userID)
                }
            }
        }
//
//        URLSession.shared.dataTask(with: URL(string: dummyUrl)!) { responseData, httpUrlResponse, error in
//            if(responseData != nil && responseData?.count != 0 && error == nil)
//            {
//                let decoder = JSONDecoder()
//                do
//                {
//                    let result = try decoder.decode([DataDummyResponse].self, from: responseData!)
//                   for data in result
//                    {
//                       debugPrint(data.title)
//                   }
//                }catch let error {
//                    debugPrint("Error is = \(error.localizedDescription)")
//                }
//            }
//        }.resume()
    }
}

let objDummyData = DummyData(_httpUtility: HttpUtility())
objDummyData.getDummydata()
























