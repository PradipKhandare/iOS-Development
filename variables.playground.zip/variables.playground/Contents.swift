var str = "Hello Pradip"
var index = 12


var name : String = "Pradip"
var mobile : Int = 0799293729
var num1 : Int
num1 = 12


var counter, num2, num3 : Double
counter = 12.12
num2 = 21.21
num3 = 32.12

var x = 0.9, y = 2.2, z = 2.1

let a : String = "Raja"


