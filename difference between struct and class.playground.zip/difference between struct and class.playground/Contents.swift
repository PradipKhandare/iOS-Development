import UIKit

//protocol Person {
//
//    var name: String{get set}
//    var phone: String{get set}
//    func personPrintInfo() -> String
//}
//
//struct empStruct: Person{
//
//    var name: String
//    var phone: String
//
//    func personPrintInfo() -> String {
//        return String()
//    }
//
//
//}


class PersonClass {
    var name: String
    var phone: String
    
    init(name: String, phone: String) {
        self.name = name
        self.phone = phone
    }
    
    func personPrintInfo() -> String {
        return "Printing value from person Class"
    }
    
    func addNumbers(x: Int, y: Int) -> Int {
        return x+y
    }
}

class HumanClass
{
    func personPrintInfo() -> String {
        return "Printing value from Human Class"
    }
}

class Emp: PersonClass, HumanClass{
    func employeePrintInfo() {
        addNumbers(x: 1, y: 1)
        personPrintInfo()
        name = "Pradip"
        phone = "7787977"
    }
}
