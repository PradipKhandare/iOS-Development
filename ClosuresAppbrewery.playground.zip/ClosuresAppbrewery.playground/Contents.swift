import UIKit

func calculator(n1: Int, n2: Int, operations: (Int, Int) -> Int) -> Int {
    return operations(n1, n2)
}

calculator(n1: 10, n2: 12, operations: {(no1: Int, no2: Int) -> Int in
return no1 * no2
})


let array = [2,3,4,5,6,9,8]
array.map({ (n1) -> Int in
    return n1 + 1
})




