var a = 5
var b = 4

a = a + b //9
b = a - b //5
a = a - b

print(a)
print(b)


var c = a
a = b
b = c

print(a)
print(b)
