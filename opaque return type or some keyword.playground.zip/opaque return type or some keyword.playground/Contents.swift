import UIKit

protocol Product
{
    associatedtype Code
    var productCode: Code {get}
    func description() -> String
}

struct Laptop: Product
{
    typealias Code = String
    var productCode: String
    
    func description() -> String {
        "this is laptop"
    }
    
}
struct Keyboard: Product
{
    typealias Code = Int
    var productCode: Int

    func description() -> String {
        "this is keyboard"
    }
}
struct Factory
{
    func makeProducts() -> some Product
    {
        return Laptop(productCode: "lenovo")
    }
    func makeProducts() -> Laptop
    {
        return Laptop(productCode: "lenovo")
    }
    func makeProducts() -> Keyboard
    {
        return Keyboard(productCode: 9)
    }
}


func SquareArrayElements<T: Numeric>(array: Array<T>) -> some Sequence
{
    return array.lazy.map{$0 * $0}
}



















